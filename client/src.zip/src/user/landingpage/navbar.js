import { useState } from "react"
import { AiOutlineClose, AiOutlineMenu } from "react-icons/ai"
import { Link, NavLink } from "react-router-dom"
import cart from "./Images/Cart1.png"
import search from "./Images/Component 2.png"
import wish from "./Images/Wishlist.png"
export default function NavBar() {
    const  [nav, setNav] = useState(false);
    const handleClick = () => {
        setNav(!nav)
    }
    return (
        <div className="flex justify-between m-auto max-w-[1240px] h-24 items-center px-4">
            <ul className = "hidden sm:flex">
                <li className = "p-4"><NavLink to="/Home" activeClassName = "border-b-2">Home</NavLink></li>
                <li className = "p-4"><NavLink to="/Contact" activeClassName = "border-b-2">Contact</NavLink></li>
                <li className = "p-4"><NavLink to="/About" activeClassName = "border-b-2">About</NavLink></li>
                <li className = "p-4"><NavLink to="/Main" activeClassName = "active: border-b-2">Sign Up</NavLink></li>
            </ul>
            <div className="hidden sm:flex items-center">
                <div className = "mx-4 flex active: border-2 relative">
                    <input type = "text" placeholder = "Looking for?" className = "px-4 focus:outline-none"></input>
                    <img src = {search} className = "hover:cursor-pointer absolute right-2"></img>
                </div>
                <img src = {wish} className = "px-2 hover: cursor-pointer"></img>
                <Link to="/cart"><img src = {cart} className = "px-2 hover: cursor-pointer"></img></Link>
            </div>
            <div onClick = {handleClick} className = "block sm:hidden ml-[97%]">
                {nav ? <AiOutlineClose></AiOutlineClose> : <AiOutlineMenu></AiOutlineMenu> }     
            </div>
            <div className = {nav ? "block sm:hidden fixed left-0 top-0  w-[60%] h-full border-r border-r-gray-900 bg-[#000300] text-white ease-in-out duration-500" : "block sm:hidden fixed left-[-100%]"}>
                <ul className = "pt-24 uppercase">
                    <li className = "p-4 border-b border-gray-2 mx-4"><NavLink to="/Home" activeClassName = "border-b">Home</NavLink></li>
                    <li className = "p-4 border-b border-gray-2 mx-4" ><NavLink to="/Contact" activeClassName = "border-b-2">Contact</NavLink></li>
                    <li className = "p-4 border-b border-gray-2 mx-4"><NavLink to="/About" activeClassName = "border-b-2">About</NavLink></li>
                    <li className = "p-4 border-b border-gray-2 mx-4"><NavLink to="/Sign Up" activeClassName = "active: border-b-2">Sign Up</NavLink></li>
                </ul>
            </div>
        </div>
    )
}