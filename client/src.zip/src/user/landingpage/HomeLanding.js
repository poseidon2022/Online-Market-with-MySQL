import OnlineMarket from "./Images/OnlineMarket.jpg"
import Laptop from "./Images/Laptop.jpg"
import Mac from "./Images/MAC.jpg"
import Typed from "react-typed"
import {NavLink, Link} from "react-router-dom"
export default function Landing() {
    return (
        <div className = "text-center flex flex-col m-4 align-middle justify-center">
            <h1 className="sm:text-4xl md:text-5xl text-3xl font-bold m-4">Online Market</h1>
            <h2 className = "sm:text-2xl md:text-3.5xl font-bold m-4">Where Quality Meets Excellence</h2>
            <div className = "w-[80%] h-[28rem] m-auto">
                <img src = {OnlineMarket} className = "rounded-2xl w-full h-full"></img>
            </div>
            <div className = "flex gap-x-6 gap-y-6 m-auto flex-wrap justify-center mt-8 max-w-[80%]">
                <div className = "w-[300px] p-4 border-r border-l transition-transform duration-300 ease-out transform hover:scale-[1.05]">
                    Upgrade your home entertainment setup or snag a powerful new laptop at incredible prices. 
                    Our electronics sale features up to 50% off on a wide selection of TVs, laptops, tablets, 
                    and more. Whether you're a gamer, a movie buff, or a productivity powerhouse, we have 
                    something for everyone. Don't miss out on these limited-time deals – shop now and 
                    start saving!
                </div>
                <div className = "w-[300px] p-4 border-r transition-transform duration-300 ease-out transform hover:scale-[1.05]">
                    Upgrade your home entertainment setup or snag a powerful new laptop at incredible prices. 
                    Our electronics sale features up to 50% off on a wide selection of TVs, laptops, tablets, 
                    and more. Whether you're a gamer, a movie buff, or a productivity powerhouse, we have 
                    something for everyone. Don't miss out on these limited-time deals – shop now and 
                    start saving!
                </div>
                <div className = "w-[300px] p-4 border-r transition-transform duration-300 ease-out transform hover:scale-[1.05]">
                    Upgrade your home entertainment setup or snag a powerful new laptop at incredible prices. 
                    Our electronics sale features up to 50% off on a wide selection of TVs, laptops, tablets, 
                    and more. Whether you're a gamer, a movie buff, or a productivity powerhouse, we have 
                    something for everyone. Don't miss out on these limited-time deals – shop now and 
                    start saving!
                </div>
            </div>
            <div className="w-[75%] mx-auto">
                <h2 className="sm:text-2xl md:text-3.5xl font-bold m-4">What's New?</h2>
                <div className="flex justify-center">
                    <img className = "w-[33%] h-auto" src = {Laptop}></img>
                    <div className="flex-col justify-center">
                        <div className="flex justify-center">
                            <img className="pl-5 w-[50%]" src = {Mac}></img>
                            <img  className="pl-5 w-[50%]" src = {Mac}></img>
                        </div>
                        <img  className="pl-5 mt-5 w-[100%] bottom-0" src = {Mac}></img>
                    </div>
                </div>
            </div>
        </div>
    )
}