import React from 'react';
import { Link, useHistory } from 'react-router-dom';
import { useCart } from '../../component/CartContext';
import { PRODUCTS } from './productdress';

function Dress() {
  const { addToCart, cartItems, subFromCart, removeFromCart, totalAmount } = useCart();
  const history = useHistory();

  const handleAddToCart = (product) => {
    addToCart(product);
  };

  const handleBuyNow = (product) => {
    addToCart(product);
    history.push('/buy');
  };

  return (
    <div className="text-grey-300 flex flex-wrap justify-center items-center gap-20 p-10 pr-96">
      {PRODUCTS.map((productDress) => (
        <div key={productDress.id}>
          <img className="w-80 h-80 object-contain" src={productDress.productImage} alt={productDress.productName} />
          <p>{productDress.productName}</p>
          <p>Birr {productDress.price}</p>
          <button onClick={() => handleAddToCart(productDress)} className="border-2 drop-shadow-2xl p-2 rounded hover:bg-gray-300">
            Add to Cart
          </button>
          <br />
          <Link to="/buy"><button  className="border-2 drop-shadow-2xl p-2 rounded hover:bg-gray-300">
            Buy
          </button></Link>
        </div>
      ))}

      <div className="fixed p-4 right-0 top-0 bg-blue-100 h-screen w-80 overflow-y-scroll">
        <h1 className="text-white font-bold text-2xl">Your Cart</h1>
        <p className="text-3xl font-bold">Total: Birr {totalAmount()}</p>
        {Object.values(cartItems).map((item) => {
          const productDress = PRODUCTS.find((product) => product.id === item.id);
          if (productDress) {
            return (
              <div key={item.id} className="mb-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <img className="w-20 h-20 my-4" src={productDress.productImage} alt={productDress.productName} />
                    <span className="text-2xl font-bold pl-2">X {item.quantity}</span>
                  </div>
                  <div className="flex flex-col gap-2 font-bold">
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-black-500 bg-gray-200 hover:bg-blue-500 hover:text-white p-2 rounded"
                    >
                      Remove
                    </button>
                    <button
                      onClick={() => addToCart(productDress)}
                      className="text-black-500 text-2xl hover:text-green-800"
                    >
                      +
                    </button>
                    <button
                      onClick={() => subFromCart(item.id)}
                      className="text-black-500 text-2xl hover:text-green-800"
                    >
                      -
                    </button>
                  </div>
                </div>
                <div className="flex items-center space-x-4 italic">
                  <p>{productDress.productName}</p>
                  <p>-</p>
                  <p>Birr {productDress.price}</p>
                </div>
              </div>
            );
          }
          return null;
        })}
      </div>
    </div>
  );
}

export default Dress;
