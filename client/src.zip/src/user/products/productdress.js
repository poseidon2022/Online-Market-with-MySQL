import dress1 from "../../images/products/dress_1.jpeg";
import dress2 from "../../images/products/dress_2.jpeg";
import dress3 from "../../images/products/dress_3.jpeg";
import dress4 from "../../images/products/dress_4.jpeg";
import dress5 from "../../images/products/dress_5.jpeg";
import dress6 from "../../images/products/dress_6.jpeg";
import dress7 from "../../images/products/dress_7.jpeg";
import dress8 from "../../images/products/dress_8.jpeg";
import dress9 from "../../images/products/dress_9.jpeg";
import dress10 from "../../images/products/dress_10.jpeg";
import dress11 from "../../images/products/dress_11.jpeg";
import dress12 from "../../images/products/dress_12.jpeg";
import dress13 from "../../images/products/dress_13.jpeg";

export const PRODUCTS = [
    {
      id: 1,
      productName: "Geez Light Blue",
      price: 3000.00 ,
      productImage: dress1,
    },
    {
      id: 2,
      productName: "Anbassa Brown (Limited Edition)",
      price: 4999.00,
      productImage: dress2,
    },
    {
      id: 3,
      productName: "Geez black",
      price: 6999.0,
      productImage: dress3,
    },
    {
      id: 4,
      productName: "Anbassa Black snickers",
      price: 2000.00 ,
      productImage: dress4,
    },
    {
      id: 5,
      productName: "Anbassa Black ",
      price: 1500.00,
      productImage: dress5,
    },
    {
      id: 6,
      productName: "Anbassa boots black",
      price: 6999.0,
      productImage: dress6,
    },
    {
      id: 7,
      productName: "Anbassa boots brown",
      price: 6999.00 ,
      productImage: dress7,
    },
    {
      id: 8,
      productName: "Anbassa Flat Shoes ",
      price: 1999.00,
      productImage: dress8,
    },
    {
      id: 9,
      productName: "Anbassa boots black-1",
      price: 6999.0,
      productImage: dress9,
    },
    {
      id: 10,
      productName: "Anbassa Protection shoes ",
      price: 9000.00 ,
      productImage: dress10,
    },
    {
      id: 11,
      productName: "Anbassa boots Brown-2",
      price: 6999.00,
      productImage: dress11,
    },
    {
      id: 12,
      productName: "Anbassa brown flat ",
      price: 2999.0,
      productImage: dress12,
    },
    {
      id: 13,
      productName: "Anbassa boots female  Black",
      price: 4000.00 ,
      productImage: dress13,
    },
    
    
    
    
  ];
