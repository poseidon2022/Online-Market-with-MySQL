import React from "react";
import { Route, BrowserRouter as Router, Switch } from 'react-router-dom';
import Dresses from "./user/products/Dresses";
import Shoes from "./user/products/Shoes";

import { CartProvider } from "./component/CartContext";
import HomePage from "./user/homepage/HomePage";
import NavBar from "./user/landingpage/navbar";
import BuyingPage from "./vendor/BuyingPage";
import CartPage from "./vendor/CartPage";
function App() {
  return (
    <CartProvider>
      <Router>
        <NavBar />
        <Switch>

          <Route exact path="/">
            <HomePage />
          </Route>

          <Route exact path="/Shoes">
            <Shoes />
          </Route>

          <Route exact path="/Dresses">
            <Dresses />
          </Route>
        //buying and cartpage router
          <Route exact path="/buy">
            <BuyingPage />
          </Route>
          <Route exact path="/cart">
            <CartPage />
          </Route>

        </Switch>




      </Router>
    </CartProvider>
    // <div>
    //   <BrowserRouter>
    //    <NavBar />
    //    <HomePage/>
    //   <Route path="/" element={<HomePage/>}/>
    //   <Route path="/" element= {<NavBar />}/>
    //   <Route path="/feedback" element={<Feedback />} />
    //   <Route path="/Contact" element={<Feedback />} />
    //   <Route path="/Home" element={<HomePage />} />
    //   <Route path="/About" element={<Feedback />} />
    //   <Route path="/Main" element={<Main />} />
    //   </BrowserRouter>
    //   <Dresses/>
    // </div>
  );
};
export default App;     